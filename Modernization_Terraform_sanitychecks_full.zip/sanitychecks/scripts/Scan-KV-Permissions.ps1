param(
  [Parameter(Mandatory=$true)][string]$adh_group,
  [Parameter(Mandatory=$true)][string]$adh_subscription_type
)
Write-Host "Running Scan-KV-Permissions for $adh_group ($adh_subscription_type)"
