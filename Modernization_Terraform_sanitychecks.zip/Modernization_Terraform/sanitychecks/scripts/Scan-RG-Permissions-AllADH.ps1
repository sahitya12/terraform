param(
    [Parameter(Mandatory=$true)][string[]]$adh_groups,
    [Parameter(Mandatory=$true)][ValidateSet("prd","nonprd")][string]$adh_subscription_type
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
foreach($g in $adh_groups){
    & "$here\Scan-RG-Permissions-ByCustodian.ps1" -adh_group $g -adh_subscription_type $adh_subscription_type
}
