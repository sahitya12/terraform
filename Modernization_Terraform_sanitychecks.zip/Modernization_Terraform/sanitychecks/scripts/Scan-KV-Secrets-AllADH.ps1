param(
    [Parameter(Mandatory=$true)][string[]]$adh_groups,
    [ValidateSet("prd","nonprd")][string]$adh_subscription_type = "nonprd"
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
foreach($g in $adh_groups){
    & "$here\Scan-KV-Secrets-ByCustodian.ps1" -adh_group $g -adh_subscription_type $adh_subscription_type
}
