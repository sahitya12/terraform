param(
    [Parameter(Mandatory=$true)][string]$adh_group,
    [ValidateSet("prd","nonprd")][string]$adh_subscription_type = "nonprd",
    [string[]]$requiredTags = @("Owner","Custodian","Environment")
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$outdir = Join-Path (Join-Path $here "..") "outputs"
if (!(Test-Path $outdir)) { New-Item -ItemType Directory -Path $outdir | Out-Null }

$rgList = az group list --query "[].{name:name,tags:tags}" -o json | ConvertFrom-Json
$rgList = $rgList | Where-Object { $_.name -like ("ADH_{0}_*" -f $adh_group) -or $_.name -like ("ADH-{0}-*" -f $adh_group) }

$rows = @()
foreach($rg in $rgList){
    foreach($t in $requiredTags){
        $has = $false
        if($rg.tags -ne $null){ $has = $rg.tags.PSObject.Properties.Name -contains $t }
        $rows += [pscustomobject]@{ ResourceGroup=$rg.name; Tag=$t; Present=($(if($has){"Yes"}else{"No"})) }
    }
}
$outFile = Join-Path $outdir ("rg_tags_{0}_{1}.csv" -f $adh_group,$adh_subscription_type)
$rows | Export-Csv -NoTypeInformation -Path $outFile
Write-Host "Wrote $outFile"
