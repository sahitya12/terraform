param([string]$adh_group = "")
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$outdir = Join-Path (Join-Path $here "..") "outputs"
if (!(Test-Path $outdir)) { New-Item -ItemType Directory -Path $outdir | Out-Null }

$adfs = az datafactory factory list -o json | ConvertFrom-Json
if($adh_group -ne ""){
    $adfs = $adfs | Where-Object { $_.name -like ("ADH-{0}-*" -f $adh_group) -or $_.name -like ("ADH_{0}_*" -f $adh_group) }
}
$rows = @()
foreach($f in $adfs){
    $pipelines = (az datafactory pipeline list -g $f.resourceGroup -n $f.name -o tsv --query "length(@)" 2>$null)
    $datasets  = (az datafactory dataset list  -g $f.resourceGroup -n $f.name -o tsv --query "length(@)" 2>$null)
    $links     = (az datafactory linked-service list -g $f.resourceGroup -n $f.name -o tsv --query "length(@)" 2>$null)
    $rows += [pscustomobject]@{ Factory=$f.name; RG=$f.resourceGroup; Location=$f.location; Pipelines=$pipelines; Datasets=$datasets; LinkedServices=$links }
}
$outFile = Join-Path $outdir "adf_inventory.csv"
$rows | Export-Csv -NoTypeInformation -Path $outFile
Write-Host "Wrote $outFile"
