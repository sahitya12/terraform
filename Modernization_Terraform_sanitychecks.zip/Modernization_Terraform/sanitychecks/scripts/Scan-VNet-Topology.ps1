$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$outdir = Join-Path (Join-Path $here "..") "outputs"
if (!(Test-Path $outdir)) { New-Item -ItemType Directory -Path $outdir | Out-Null }

$vnets = az network vnet list -o json | ConvertFrom-Json
$rows = @()
foreach($v in $vnets){
    foreach($p in ($v.peerings | ForEach-Object { $_ })) {
        $rows += [pscustomobject]@{
            VNet=$v.name; ResourceGroup=$v.resourceGroup; Location=$v.location;
            PeeringName=$p.name; RemoteVNetId=$p.remoteVirtualNetwork.id; PeeringState=$p.peeringState
        }
    }
    foreach($s in ($v.subnets | ForEach-Object { $_ })) {
        $rows += [pscustomobject]@{
            VNet=$v.name; ResourceGroup=$v.resourceGroup; Location=$v.location;
            PeeringName=""; RemoteVNetId="";
            PeeringState=""; Subnet=$s.name; Prefix=($s.addressPrefix -join ",")
        }
    }
}
$outFile = Join-Path $outdir "vnet_topology.csv"
$rows | Export-Csv -NoTypeInformation -Path $outFile
Write-Host "Wrote $outFile"
