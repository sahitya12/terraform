param(
    [Parameter(Mandatory=$true)][string]$adh_group,
    [ValidateSet("prd","nonprd")][string]$adh_subscription_type = "nonprd"
)
param([string]$keyVaultName)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Join-Path $here ".."
$inputs = Join-Path $root "inputs"
$outdir = Join-Path $root "outputs"; if(!(Test-Path $outdir)){New-Item -ItemType Directory -Path $outdir|Out-Null}

$envShort = if($adh_subscription_type -eq "prd"){"prd"}else{"dev"}
if([string]::IsNullOrEmpty($keyVaultName)){
    $keyVaultName = "ADH-{0}-KV-{1}" -f $adh_group,$envShort
}

$secretList = Import-Csv (Join-Path $inputs "kvsecretsscan.csv")
$rows = @()
foreach($s in $secretList){
    $name = $s.SECRET_NAME
    $exists = $false
    try {
        $val = az keyvault secret show --vault-name $keyVaultName --name $name -o json 2>$null | ConvertFrom-Json
        $exists = ($null -ne $val)
    } catch {}
    $rows += [pscustomobject]@{ KeyVault=$keyVaultName; SecretName=$name; Exists=($(if($exists){"Yes"}else{"No"})) }
}
$outFile = Join-Path $outdir ("kv_secrets_{0}_{1}.csv" -f $adh_group,$adh_subscription_type)
$rows | Export-Csv -NoTypeInformation -Path $outFile
Write-Host "Wrote $outFile"
