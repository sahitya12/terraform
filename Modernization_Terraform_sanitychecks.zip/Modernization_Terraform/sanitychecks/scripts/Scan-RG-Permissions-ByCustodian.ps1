param(
    [Parameter(Mandatory=$true)][string]$adh_group,
    [Parameter(Mandatory=$true)][ValidateSet("prd","nonprd")][string]$adh_subscription_type
)
<#
Checks role assignments for RGs against inputs/{prod|nonprod}_permissions.csv.
Outputs: outputs/rg_permissions_<adh_group>_<adh_subscription_type>.csv
#>

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Join-Path $here ".."
$inputs = Join-Path $root "inputs"
$outdir = Join-Path $root "outputs"
if (!(Test-Path $outdir)) { New-Item -ItemType Directory -Path $outdir | Out-Null }

$csvPath = Join-Path $inputs ("{0}_permissions.csv" -f (if($adh_subscription_type -eq "prd"){"prod"}else{"nonprod"}))
if (!(Test-Path $csvPath)) { Write-Error "Missing input CSV $csvPath"; exit 1 }

$exp = Import-Csv $csvPath
$exp = $exp | ForEach-Object {
    $_.resource_group_name = $_.resource_group_name -replace "<Custodian>", $adh_group
    $_.ad_group_name = $_.ad_group_name -replace "<Custodian>", $adh_group
    $_
}

$rgList = az group list --query "[].name" -o tsv 2>$null
$assignments = az role assignment list --all -o json | ConvertFrom-Json

$rows = @()
foreach($e in $exp){
    $rg = $e.resource_group_name
    $role = $e.role_definition_name
    $principalName = $e.ad_group_name

    $exists = $false
    if ($rgList -contains $rg) {
        $match = $assignments | Where-Object {
            $_.scope -match "/resourceGroups/$rg($|/)" -and
            $_.roleDefinitionName -eq $role -and
            ($_.principalName -eq $principalName -or $_.principalName -like "$principalName*")
        }
        $exists = ($match.Count -gt 0)
    } else {
        $rows += [pscustomobject]@{ ResourceGroup=$rg; Role=$role; Principal=$principalName; Exists="RG Not Found" }
        continue
    }

    $rows += [pscustomobject]@{ ResourceGroup=$rg; Role=$role; Principal=$principalName; Exists=($(if($exists){"Yes"}else{"No"})) }
}

$outFile = Join-Path $outdir ("rg_permissions_{0}_{1}.csv" -f $adh_group,$adh_subscription_type)
$rows | Export-Csv -NoTypeInformation -Path $outFile
Write-Host "Wrote $outFile"
