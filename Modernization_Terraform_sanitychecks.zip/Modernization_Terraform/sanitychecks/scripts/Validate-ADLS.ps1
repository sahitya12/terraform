param(
    [Parameter(Mandatory=$true)][string]$adh_group,
    [Parameter(Mandatory=$true)][ValidateSet("prd","nonprd")][string]$adh_subscription_type
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Join-Path $here ".."
$inputs = Join-Path $root "inputs"
$outdir = Join-Path $root "outputs"; if(!(Test-Path $outdir)){New-Item -ItemType Directory -Path $outdir|Out-Null}

$csv = Join-Path $inputs "adls_permissions.csv"
if(!(Test-Path $csv)){ Write-Error "Missing $csv"; exit 1 }

$short = if($adh_subscription_type -eq "prd"){"prd"}else{"nonprd"}
$shortCust = ($adh_group.Substring(0,[Math]::Min(3,$adh_group.Length))).ToLower()

$exp = Import-Csv $csv | ForEach-Object {
    $_.ResourceGroupName = $_.ResourceGroupName -replace "<Custodian>", $adh_group
    $_.StorageAccountName = $_.StorageAccountName -replace "<Cust>", $shortCust
    $_.Identity = $_.Identity -replace "<Custodian>", $adh_group
    $_
}

$rows = @()
foreach($e in $exp){
    $sa = $e.StorageAccountName
    $container = $e.ContainerName
    $path = $e.AccessPath
    $id = $e.Identity
    $perm = $e.PermissionType
    $scope = $e.Scope

    $ok = $false
    try{
        $acl = az storage fs access show --account-name $sa --path $path --file-system $container -o json 2>$null | ConvertFrom-Json
        if($acl){ $ok = $true }
    } catch {}

    $rows += [pscustomobject]@{
        ResourceGroup=$e.ResourceGroupName
        StorageAccount=$sa
        Container=$container
        AccessPath=$path
        Expected="$($id) $($perm) $($scope)"
        Actual= $(if($ok){"Found ACL"}else{"Not Found"})
        Result= $(if($ok){"Compliant"}else{"Drift"})
    }
}

$outFile = Join-Path $outdir ("adls_validate_findings_{0}_{1}.csv" -f $adh_group,$adh_subscription_type)
$rows | Export-Csv -NoTypeInformation -Path $outFile
Write-Host "Wrote $outFile"
