param(
    [Parameter(Mandatory=$true)][string]$adh_group,
    [ValidateSet("prd","nonprd")][string]$adh_subscription_type = "nonprd",
    [string]$keyVaultName
)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Join-Path $here ".."
$outdir = Join-Path $root "outputs"; if(!(Test-Path $outdir)){New-Item -ItemType Directory -Path $outdir|Out-Null}

$envShort = if($adh_subscription_type -eq "prd"){"prd"}else{"dev"}
if([string]::IsNullOrEmpty($keyVaultName)){
    $keyVaultName = "ADH-{0}-KV-{1}" -f $adh_group,$envShort
}

$kv = az keyvault show -n $keyVaultName -o json 2>$null | ConvertFrom-Json
if($null -eq $kv){ Write-Error "Key vault $keyVaultName not found"; exit 1 }

$net = az keyvault network-rule list --name $keyVaultName -o json 2>$null | ConvertFrom-Json
$rows = @()

$defAction = ($kv.properties.networkAcls.defaultAction)
$bp = ($kv.properties.networkAcls.bypass)

$rows += [pscustomobject]@{ KeyVault=$keyVaultName; Setting="DefaultAction"; Value=$defAction }
$rows += [pscustomobject]@{ KeyVault=$keyVaultName; Setting="Bypass"; Value=$bp }

if($net){
    foreach($ip in $net.ipRules){ $rows += [pscustomobject]@{ KeyVault=$keyVaultName; Setting="IPRule"; Value=$ip.value } }
    foreach($v in $net.virtualNetworkRules){ $rows += [pscustomobject]@{ KeyVault=$keyVaultName; Setting="VNetRule"; Value=$v.id } }
}

$outFile = Join-Path $outdir ("kv_firewall_{0}_{1}.csv" -f $adh_group,$adh_subscription_type)
$rows | Export-Csv -NoTypeInformation -Path $outFile
Write-Host "Wrote $outFile"
