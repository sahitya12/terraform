# Sanity Checks Pack (Variable Groups Auth)

- Auth is performed with `az login` using SPN details from variable groups
  - **prd**: `moderanization_tfstate_backend_details` + `moderanization_terraform_subscription_details`
  - **nonprd**: `test_moderanization_tfstate_backend_details` + `test_moderanization_terraform_subscription_details`
- Subscription id is read from a variable in the subscription group named:
  **`<adh_group>_<adh_subscription_type>_subscription_id`**

## Agent Pool Naming
The pool is computed as `<adh_group>_<adh_subscription_type>_agent<index>`.

## Inputs
- `inputs/prod_permissions.csv`
- `inputs/nonprod_permissions.csv`
- `inputs/kvsecretsscan.csv`
- `inputs/adls_permissions.csv`

## Outputs
Runtime outputs will be written into `sanitychecks/outputs/`.
Samples are provided under `outputs_samples/`.