param(
  [Parameter(Mandatory=$true)][string]$TenantId,
  [Parameter(Mandatory=$true)][string]$ClientId,
  [Parameter(Mandatory=$true)][string]$ClientSecret,
  [Parameter(Mandatory=$true)][string]$ProdCsvPath,
  [Parameter(Mandatory=$true)][string]$NonProdCsvPath,
  [Parameter(Mandatory=$true)][string]$adh_group,
  [string]$adh_subscription_type='',
  [string]$OutputDir="",
  [string]$BranchName=""
)
$ErrorActionPreference='Stop'
function Ensure-Dir([string]$p){ if([string]::IsNullOrWhiteSpace($p)){ $p = Join-Path (Get-Location) 'rg-perms-out' } if(-not(Test-Path $p)){ New-Item -ItemType Directory -Path $p -Force | Out-Null } return $p }
function Normalize([string]$s){ ($s -replace '[_\s]','').ToLowerInvariant() }
function Load-Expected($p){ if(-not(Test-Path $p)){ throw "CSV not found: $p" } $raw=Import-Csv $p; if(-not $raw){ throw "CSV empty: $p" } $map=@{}; foreach($h in $raw[0].psobject.Properties.Name){ $map[(Normalize $h)]=$h } foreach($need in 'resourcegroupname','roledefinitionname','adgroupname'){ if(-not $map.ContainsKey($need)){ throw "CSV '$p' missing column like '$need'" } } $rows=@(); foreach($r in $raw){ $rows += [pscustomobject]@{ RG="$($r.$($map['resourcegroupname']))".Trim(); Role="$($r.$($map['roledefinitionname']))".Trim(); AAD="$($r.$($map['adgroupname']))".Trim() } }; $rows }
function Get-EnvFromSub([string]$n){ if($n -match '(?i)\b(prod|prd|production)\b'){ 'PRODUCTION' } else { 'NONPRODUCTION' } }
function Resolve-Group([string]$name){ if([string]::IsNullOrWhiteSpace($name)){ return $null } try{ $g=Get-AzADGroup -DisplayName $name -ErrorAction Stop; return $g }catch{ try{ return (Get-AzADGroup -SearchString $name -ErrorAction Stop | ?{ $_.DisplayName -eq $name } | select -First 1) }catch{ return $null } } }
Import-Module Az.Accounts -ErrorAction Stop; Import-Module Az.Resources -ErrorAction Stop
$sec=ConvertTo-SecureString $ClientSecret -AsPlainText -Force; $cred=[pscredential]::new($ClientId,$sec); Connect-AzAccount -ServicePrincipal -Tenant $TenantId -Credential $cred | Out-Null
$OutputDir=Ensure-Dir $OutputDir; $stamp=(Get-Date).ToString('yyyyMMdd_HHmmss'); $outCsv=Join-Path $OutputDir "rg_permissions_${adh_group}_$stamp.csv"
$rowsProd=Load-Expected $ProdCsvPath; $rowsNon=Load-Expected $NonProdCsvPath; $list = New-Object System.Collections.Generic.List[object]
$subs = Get-AzSubscription | ? { $_.Name -match "(?i)$($adh_subscription_type).*ADH$($adh_group)" }
if(-not $subs){ Write-Warning "No subscriptions matched pattern: $adh_subscription_type .* ADH$adh_group" }
foreach($sub in $subs){ Set-AzContext -SubscriptionId $sub.Id -Tenant $TenantId | Out-Null; $env = Get-EnvFromSub $sub.Name; $expected = if($env -eq 'PRODUCTION'){ $rowsProd } else { $rowsNon }; $rgList = Get-AzResourceGroup -ErrorAction SilentlyContinue; $rgMap = @{}; foreach($rg in $rgList){ $rgMap[$rg.ResourceGroupName.ToLowerInvariant()]=$rg }; foreach($e in $expected){ $rgName = ($e.RG -replace '<Custodian>', $adh_group); $roleName = ($e.Role -replace '<Custodian>', $adh_group); $aadName = ($e.AAD -replace '<Custodian>', $adh_group); $rgObj = $null; $key = $rgName.ToLowerInvariant(); if($rgMap.ContainsKey($key)){ $rgObj = $rgMap[$key] } if(-not $rgObj){ $list.Add([pscustomobject]@{SubscriptionName=$sub.Name; SubscriptionId=$sub.Id; Environment=$env; ResourceGroup=$rgName; Role=$roleName; AADGroup=$aadName; Status='RG_NOT_FOUND'}) ; continue } $grp = Resolve-Group $aadName; if(-not $grp){ $list.Add([pscustomobject]@{SubscriptionName=$sub.Name; SubscriptionId=$sub.Id; Environment=$env; ResourceGroup=$rgName; Role=$roleName; AADGroup=$aadName; Status='AAD_GROUP_NOT_FOUND'}) ; continue } $scope = "/subscriptions/$($sub.Id)/resourceGroups/$rgName"; $ra = Get-AzRoleAssignment -Scope $scope -ObjectId $grp.Id -RoleDefinitionName $roleName -ErrorAction SilentlyContinue; $list.Add([pscustomobject]@{SubscriptionName=$sub.Name; SubscriptionId=$sub.Id; Environment=$env; ResourceGroup=$rgName; Role=$roleName; AADGroup=$aadName; Status=$(if($ra){'OK'}else{'MISSING_ROLE_ASSIGNMENT'})}) } }
$list | Export-Csv -NoTypeInformation -Encoding UTF8 $outCsv; Write-Host "CSV: $outCsv"
