param([Parameter(Mandatory=$true)][string]$TenantId,[Parameter(Mandatory=$true)][string]$ClientId,[Parameter(Mandatory=$true)][string]$ClientSecret,[string]$adh_group='',[string]$adh_subscription_type='',[string]$OutputDir="",[string]$BranchName="")
$ErrorActionPreference='Stop'; Import-Module Az.Accounts -ErrorAction Stop; Import-Module Az.Network -ErrorAction Stop
$sec=ConvertTo-SecureString $ClientSecret -AsPlainText -Force; $cred=[pscredential]::new($ClientId,$sec); Connect-AzAccount -ServicePrincipal -Tenant $TenantId -Credential $cred | Out-Null
$OutputDir= if($OutputDir){$OutputDir}else{Join-Path (Get-Location) 'vnet-out'}; if(-not(Test-Path $OutputDir)){ New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
$stamp=(Get-Date).ToString('yyyyMMdd_HHmmss'); $out=Join-Path $OutputDir "vnet_topology_$stamp.csv"
$subs = if([string]::IsNullOrWhiteSpace($adh_group)){ Get-AzSubscription } else { Get-AzSubscription | ? { $_.Name -match "(?i)$($adh_subscription_type).*ADH$($adh_group)" } }
$rows=New-Object System.Collections.Generic.List[object]
foreach($s in $subs){ Set-AzContext -SubscriptionId $s.Id -Tenant $TenantId | Out-Null; foreach($vnet in Get-AzVirtualNetwork){ $subsList = ($vnet.Subnets | %{$_.Name}) -join ';'; $peers = ($vnet.Peerings | %{$_.RemoteVirtualNetwork.Id}) -join ';'; $rtLinks = ($vnet.Subnets | %{$_.RouteTable?.Id}) -join ';'; $rows.Add([pscustomobject]@{Subscription=$s.Name; VNetName=$vnet.Name; RG=$vnet.ResourceGroupName; AddressSpace=($vnet.AddressSpace.AddressPrefixes -join ','); Subnets=$subsList; Peerings=$peers; RouteTables=$rtLinks}) } }
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out; Write-Host "CSV: $out"
