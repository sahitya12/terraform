param([Parameter(Mandatory=$true)][string]$TenantId,[Parameter(Mandatory=$true)][string]$ClientId,[Parameter(Mandatory=$true)][string]$ClientSecret,[Parameter(Mandatory=$true)][string]$adh_group,[string]$adh_subscription_type='',[string]$OutputDir="",[string]$BranchName="")
$ErrorActionPreference='Stop'; Import-Module Az.Accounts -ErrorAction Stop; Import-Module Az.Resources -ErrorAction Stop
function Ensure-Dir([string]$p){ if([string]::IsNullOrWhiteSpace($p)){ $p = Join-Path (Get-Location) 'rg-tags-out' } if(-not(Test-Path $p)){ New-Item -ItemType Directory -Path $p -Force | Out-Null } return $p }
$sec=ConvertTo-SecureString $ClientSecret -AsPlainText -Force; $cred=[pscredential]::new($ClientId,$sec); Connect-AzAccount -ServicePrincipal -Tenant $TenantId -Credential $cred | Out-Null
$OutputDir=Ensure-Dir $OutputDir; $stamp=(Get-Date).ToString('yyyyMMdd_HHmmss'); $outCsv=Join-Path $OutputDir "rg_tags_${adh_group}_$stamp.csv"
$subs = Get-AzSubscription | ? { $_.Name -match "(?i)$($adh_subscription_type).*ADH$($adh_group)" }
$rows = New-Object System.Collections.Generic.List[object]
foreach($s in $subs){ Set-AzContext -SubscriptionId $s.Id -Tenant $TenantId | Out-Null; foreach($rg in Get-AzResourceGroup){ $flat = if($rg.Tags){ ($rg.Tags.GetEnumerator()|%{"$($_.Key)=$($_.Value)"}) -join '; ' } else { '' }; $rows.Add([pscustomobject]@{SubscriptionName=$s.Name; ResourceGroup=$rg.ResourceGroupName; Tags=$flat}) } }
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $outCsv; Write-Host "CSV: $outCsv"
