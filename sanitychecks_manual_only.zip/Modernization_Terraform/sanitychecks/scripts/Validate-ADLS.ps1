param([Parameter(Mandatory=$true)][string]$TenantId,[Parameter(Mandatory=$true)][string]$ClientId,[Parameter(Mandatory=$true)][string]$ClientSecret,[Parameter(Mandatory=$true)][string]$CsvPath,[string]$adh_group='',[string]$adh_subscription_type='',[string]$OutputDir="",[string]$BranchName="")
$ErrorActionPreference='Stop'; Import-Module Az.Accounts -ErrorAction Stop; Import-Module Az.Storage -ErrorAction Stop; Import-Module Az.Resources -ErrorAction Stop
$sec=ConvertTo-SecureString $ClientSecret -AsPlainText -Force; $cred=[pscredential]::new($ClientId,$sec); Connect-AzAccount -ServicePrincipal -Tenant $TenantId -Credential $cred | Out-Null
$OutputDir= if($OutputDir){$OutputDir}else{Join-Path (Get-Location) 'adls-out'}; if(-not(Test-Path $OutputDir)){ New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
$stamp=(Get-Date).ToString('yyyyMMdd_HHmmss'); $out=Join-Path $OutputDir "adls_validate_$stamp.csv"
$in = Import-Csv $CsvPath
$rows=New-Object System.Collections.Generic.List[object]
foreach($r in $in){
  $cust = $adh_group
  $sa = if($adh_subscription_type -eq 'prd') { "adh$($cust)adlsprd" } else { "adh$($cust)adlsnonprd" }
  $exists=$false
  try{ $acc = Get-AzStorageAccount | ? { $_.StorageAccountName -eq $sa } | Select-Object -First 1; if($acc){ $exists=$true } }catch{}
  $rows.Add([pscustomobject]@{Custodian=$cust; StorageAccount=$sa; Container=$($r.ContainerName); Identity=$($r.Identity); AccessPath=$($r.AccessPath); PermissionType=$($r.PermissionType); Type=$($r.Type); Scope=$($r.Scope); SAExists=$(if($exists){'YES'}else{'NO'})})
}
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 $out; Write-Host "CSV: $out"
