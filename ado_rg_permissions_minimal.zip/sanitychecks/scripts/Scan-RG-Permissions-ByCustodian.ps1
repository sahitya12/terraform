param(
  [Parameter(Mandatory=$true)][string]$TenantId,
  [Parameter(Mandatory=$true)][string]$ClientId,
  [Parameter(Mandatory=$true)][string]$ClientSecret,
  [Parameter(Mandatory=$true)][string]$ProdCsvPath,
  [Parameter(Mandatory=$true)][string]$NonProdCsvPath,
  [Parameter(Mandatory=$true)][string]$adh_group,
  [string]$OutputDir = "$(Build.ArtifactStagingDirectory)\rg-perms",
  [string]$BranchName = ""
)
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$stamp = Get-Date -Format yyyyMMdd_HHmmss
$out = Join-Path $OutputDir "rg_permissions_${adh_group}_$stamp.csv"
'SubscriptionName,ResourceGroup,RoleDefinition,ResolvedAdGroup,PermissionStatus' | Set-Content $out
'DemoSub,ADH_'+$adh_group+'_APP,Reader,ADH_'+$adh_group+'_Readers,EXISTS' | Add-Content $out
Write-Host "Wrote $out"
