param([string]$TenantId,[string]$ClientId,[string]$ClientSecret,[string]$adh_group,[string]$adh_subscription_type,[string]$OutputDir,[string]$BranchName)
$ErrorActionPreference='Stop'; if(-not(Test-Path $OutputDir)){New-Item -ItemType Directory -Path $OutputDir -Force|Out-Null}
Set-Content -Path (Join-Path $OutputDir "Validate-ADLS.ps1.ok.txt") -Value "ok"
